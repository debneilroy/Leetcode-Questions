// https://leetcode.com/problems/binary-tree-right-side-view

# Solution : https://github.com/debneilroy/Leetcode-Questions/blob/master/Facebook/Trees%20and%20Graphs/Binary%20Tree%20Right%20Side%20View.ipynb

# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right

# Approach : BFS Level Order Traversal

class Solution:
    def rightSideView(self, root: Optional[TreeNode]) -> List[int]:
        if not root:
            return []

        queue = deque([root])
        rightside = []

        while queue:
            level_length = len(queue)

            for i in range(level_length):
                node = queue.popleft()

                if i == level_length - 1:
                    rightside.append(node.val)

                if node.left:
                    queue.append(node.left)

                if node.right:
                    queue.append(node.right)

        return rightside

# TC : O(N) since one has to visit each node.
# SC : O(D) to keep the queues, where D is a tree diameter. Let's use the last level to estimate the queue size. This level could contain up to N/2 tree nodes in the case of a complete binary tree.
        
# Approach : Recursive DFS

# class Solution:
#     def rightSideView(self, root: TreeNode) -> List[int]:
#         if root is None:
#             return []
        
#         rightside = []
        
#         def helper(node: TreeNode, level: int) -> None:
#             if level == len(rightside):
#                 rightside.append(node.val)
#             for child in [node.right, node.left]:
#                 if child:
#                     helper(child, level + 1)
                
#         helper(root, 0)
#         return rightside

# TC : O(N) since one has to visit each node.
# SC : O(H) to keep the recursion stack, where H is a tree height. The worst-case situation is a skewed tree, when H = N.