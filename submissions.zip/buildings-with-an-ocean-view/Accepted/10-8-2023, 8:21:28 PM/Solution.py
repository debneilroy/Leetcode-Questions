// https://leetcode.com/problems/buildings-with-an-ocean-view

# Brute Force    TC : O(N^2)   SC : O(1)

# class Solution:
#     def findBuildings(self, heights: List[int]) -> List[int]:
#         ans = []

#         for i in range(len(heights)-1):
#             if heights[i] > max(heights[i+1:]):
#                 ans.append(i)

#         ans.append(len(heights)-1)

#         return ans


# Traverse array from right to left      TC : O(N)    SC : O(1)

class Solution:
    def findBuildings(self, heights: List[int]) -> List[int]:

        ans = []
        maxHeight = 0

        for i in range(len(heights)-1, -1, -1):
            if heights[i] > maxHeight:
                ans.append(i)
                maxHeight = heights[i]

        return ans[::-1]
        