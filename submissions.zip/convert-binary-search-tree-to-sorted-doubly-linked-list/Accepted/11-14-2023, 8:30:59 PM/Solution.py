// https://leetcode.com/problems/convert-binary-search-tree-to-sorted-doubly-linked-list

"""
# Definition for a Node.
class Node:
    def __init__(self, val, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right
"""

class Solution:
    def treeToDoublyList(self, root: 'Optional[Node]') -> 'Optional[Node]':
        if not root:
            return None

        self.first = None # smallest node
        self.last = None # largest node

        self.inorder_link(root)

        self.first.left = self.last
        self.last.right = self.first

        return self.first

    def inorder_link(self, node):
        """
        Performs standard inorder traversal:
        left -> node -> right
        and links all nodes into DLL
        """
        if node:
            self.inorder_link(node.left)

            if not self.last:
                self.first = node
            else:
                node.left = self.last
                self.last.right = node

            self.last = node

            self.inorder_link(node.right)
        
# Complexity Analysis

# Time complexity : O(N) since each node is processed exactly once.

# Space complexity : O(N). We have to keep a recursion stack of the size of the tree height, which is O(log N) for the best case of completely balanced tree and O(N) for the worst case of completely unbalanced tree.