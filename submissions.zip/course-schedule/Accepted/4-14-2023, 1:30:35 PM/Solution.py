// https://leetcode.com/problems/course-schedule

class Solution:
    def canFinish(self, numCourses: int, prerequisites: List[List[int]]) -> bool:

        # define prerequisite map
        preMap = {i:[] for i in range(numCourses)}

        for crs, pre in prerequisites:
            preMap[crs].append(pre)

        visit = set() # keep track of all courses along current DFS path

        def dfs(crs):
            # base cases
            if crs in visit: # the course has been visited twice, loop detected
                return False
            if preMap[crs] == []: # course has no prerequisites
                return True

            visit.add(crs)

            # loop through all prerequisites of this course and run DFS
            for pre in preMap[crs]:
                if not dfs(pre):
                    return False

            visit.remove(crs) # remove the course, since it has been visited
            preMap[crs] = [] # set prerequisites to an empty list

            return True

        # loop through all courses in case graph is not fully connected, e.g., 1->2, 3->4
        for crs in range(numCourses):
            if not dfs(crs):
                return False

        return True


# TC : O(N+P), where N is the number of courses and P is the number of prereuisites
# SC : O(N+P)


    


        


        