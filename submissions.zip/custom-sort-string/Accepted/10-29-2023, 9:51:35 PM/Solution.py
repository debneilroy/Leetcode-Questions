// https://leetcode.com/problems/custom-sort-string

class Solution:
    def customSortString(self, order: str, s: str) -> str:

        count = {}
        ans = []

        for i in range(len(s)):
            if s[i] in count:
                count[s[i]] += 1
            else:
                count[s[i]] = 1

        for c in order:
            if c in s:
                ans.append(c*count[c])
                count[c] = 0

        for c in count:
            ans.append(c*count[c])

        return "".join(ans)

        