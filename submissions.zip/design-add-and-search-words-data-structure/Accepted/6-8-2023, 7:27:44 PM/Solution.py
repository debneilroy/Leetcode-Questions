// https://leetcode.com/problems/design-add-and-search-words-data-structure

class TrieNode:
    def __init__(self):
        self.children = {}
        self.endWord = False

class WordDictionary:

    def __init__(self):
        self.root = TrieNode()

    def addWord(self, word: str) -> None: 
        curr = self.root

        for c in word:
            if c not in curr.children:
                curr.children[c] = TrieNode()
            curr = curr.children[c]
        curr.endWord = True

    def search(self, word: str) -> bool:

        def dfs(j, root):
            curr = root

            for i in range(j, len(word)):
                c = word[i]

                if c == '.':
                    for child in curr.children.values():
                        if dfs(i+1, child):
                            return True
                    return False
                else:
                    if c not in curr.children:
                        return False
                    curr = curr.children[c]
            return curr.endWord

        return dfs(0, self.root)
        
# Read about time and space complexity

# class WordDictionary:
#     def __init__(self):
#         self.d = defaultdict(set)


#     def addWord(self, word: str) -> None:
#         self.d[len(word)].add(word)


#     def search(self, word: str) -> bool:
#         m = len(word)
#         for dict_word in self.d[m]:
#             i = 0
#             while i < m and (dict_word[i] == word[i] or word[i] == '.'):
#                 i += 1
#             if i == m:
#                 return True
#         return False

