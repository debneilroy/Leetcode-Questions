// https://leetcode.com/problems/design-log-storage-system

#gmap = { 'Year': 1, 'Month': 2, 'Day': 3, 'Hour': 4, 'Minute': 5, 'Second': 6 }

class LogSystem:
    def __init__(self):
        self.d = {}
        self.gmap = { 'Year': 1, 'Month': 2, 'Day': 3, 'Hour': 4, 'Minute': 5, 'Second': 6 }
        
    def put(self, id, timestamp):
        t = tuple(timestamp.split(':'))
        self.d[t] = id

    def retrieve(self, s, e, gra):
        idx = self.gmap[gra]     # Prune from this index onwards
        s = tuple(s.split(':')[:idx])
        e = tuple(e.split(':')[:idx])

        ans = []
        for t in self.d.keys():
            if s <= t[:idx] <= e:
                ans.append(self.d[t])
        return ans
        


# Your LogSystem object will be instantiated and called as such:
# obj = LogSystem()
# obj.put(id,timestamp)
# param_2 = obj.retrieve(start,end,granularity)