// https://leetcode.com/problems/diagonal-traverse

# https://www.youtube.com/watch?v=FH9BxnzumVo

class Solution:
    def findDiagonalOrder(self, mat: List[List[int]]) -> List[int]:
        rows, cols = len(mat), len(mat[0])
        res = []
        
        curr_row = curr_col = 0
        going_up = True

        while len(res) != rows * cols:
            if going_up:
                while curr_row >= 0 and curr_col < cols:
                    res.append(mat[curr_row][curr_col])
                    curr_row -= 1
                    curr_col += 1

                if curr_col == cols:
                    curr_col -= 1
                    curr_row += 2
                else:
                    curr_row += 1

                going_up = False

            else:
                while curr_col >= 0 and curr_row < rows:
                    res.append(mat[curr_row][curr_col])
                    curr_row += 1
                    curr_col -= 1

                if curr_row == rows:
                    curr_row -= 1
                    curr_col += 2  
                else:
                    curr_col += 1

                going_up = True
        
        return res

# TC : O(M*N), where M is the number of rows and N is the number of columns
# SC : O(1)