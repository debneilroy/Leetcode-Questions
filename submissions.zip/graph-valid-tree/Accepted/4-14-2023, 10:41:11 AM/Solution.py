// https://leetcode.com/problems/graph-valid-tree

class Solution:
    def validTree(self, n: int, edges: List[List[int]]) -> bool:
        if not n: # if there are no nodes then it is a tree
            return True

        # create adjacency list of the form {node : [neighbors]}
        adj = {i:[] for i in range(n)}
        for n1, n2 in edges:
            adj[n1].append(n2)
            adj[n2].append(n1)

        visit = set() # create a set to keep track of all visited nodes

        def dfs(i, prev):
            # this function checks whether there is a cycle in the graph, if not, returns True

            if i in visit: # cycle detected
                return False 

            visit.add(i)

            # loop through all neighbors of the node
            for j in adj[i]:
                if j == prev: # if the neighbor happens to be its previous node
                    continue

                if not dfs(j,i): # if a cycle is detected
                    return False

            return True


        # check if the graph contains no cycles and whether all nodes are connected for it to be a valid tree; previous node of 0 can be taken as -1

        return dfs(0, -1) and n == len(visit) 




# Complexity Analysis : Let E be the number of edges, and N be the number of nodes.

# TC : O(N+E)
# SC : O(N+E)




            