// https://leetcode.com/problems/house-robber-ii

class Solution:
    def rob(self, nums: List[int]) -> int:
        # return the max that can be robbed of three cases : only one house, all houses except the first house and all houses except the last house
        return max(nums[0], self.helper(nums[1:]), self.helper(nums[:-1]))


    def helper(self, nums): 
        rob1, rob2 = 0, 0

        for n in nums:
            newRob = max(n+rob1, rob2)
            rob1 = rob2
            rob2 = newRob

        return rob2
