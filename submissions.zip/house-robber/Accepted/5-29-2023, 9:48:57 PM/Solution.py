// https://leetcode.com/problems/house-robber

class Solution:
    def rob(self, nums: List[int]) -> int:

        rob1, rob2 = 0, 0 

        for n in nums:
            temp = max(n+rob1, rob2) # calculate how much can be robbed till the current house
            rob1 = rob2
            rob2 = temp

        return rob2

# TC : O(n) SC : O(1)