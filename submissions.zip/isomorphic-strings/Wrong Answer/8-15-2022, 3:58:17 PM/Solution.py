// https://leetcode.com/problems/isomorphic-strings

from collections import Counter
class Solution:
    def isIsomorphic(self, s: str, t: str) -> bool:
        
        dict_s = Counter(s)
        dict_t = Counter(t)
        
        return (list(dict_s.values())) == (list(dict_t.values()))
        