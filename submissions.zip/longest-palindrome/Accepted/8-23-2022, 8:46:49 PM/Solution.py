// https://leetcode.com/problems/longest-palindrome

class Solution:
    def longestPalindrome(self, s: str) -> int:
        
        hashmap = set()
        for letter in s:
            if letter not in hashmap:
                hashmap.add(letter)
            else:
                hashmap.remove(letter)
        if len(hashmap) != 0:
            return len(s) - len(hashmap) + 1
        else:
            return len(s)