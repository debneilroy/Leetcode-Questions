// https://leetcode.com/problems/longest-palindromic-substring



# Brute Force
# TC : O(n^3), SC : O(1)
# class Solution:
#     def longestPalindrome(self, s):
#         if len(s) == 1: return s
#         if s == s[::-1]: return s
        
#         count = 0
        
#         for i in range(len(s)):
#             for j in range(i,len(s) +1):
#                 pal = s[i:j]
#                 if pal == pal[::-1] and len(pal) > count:
#                     result = pal
#                     count = len(pal)
#         return result
        

# Expand around center
# TC : O(n^2), SC : O(1)

class Solution:
    def longestPalindrome(self, s):
        res = ""
        resLen = 0

        for i in range(len(s)):
            # odd length
            l, r = i, i

            while l >= 0 and r < len(s) and s[l] == s[r]:
                if (r-l+1) > resLen:
                    res = s[l:r+1]
                    resLen = r-l+1
                l -= 1
                r += 1

            # even length
            l, r = i, i+1

            while l >= 0 and r < len(s) and s[l] == s[r]:
                if (r-l+1) > resLen:
                    res = s[l:r+1]
                    resLen = r-l+1
                l -= 1
                r += 1

        return res

            
