// https://leetcode.com/problems/longest-palindromic-substring

class Solution:
    def longestPalindrome(self, s):
        if len(s) == 1: return s
        if s == s[::-1]: return s
        
        count = 0
        
        for i in range(len(s)):
            for j in range(i,len(s) +1):
                pal = s[i:j]
                if pal == pal[::-1] and len(pal) > count:
                    result = pal
                    count = len(pal)
        return result
        