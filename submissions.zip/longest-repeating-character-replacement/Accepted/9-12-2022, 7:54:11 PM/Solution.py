// https://leetcode.com/problems/longest-repeating-character-replacement

class Solution:
    def characterReplacement(self, s: str, k: int) -> int:
        
        l = 0
        freq = {}
        maxlen = 0
        
        for r in range(len(s)):
            if s[r] not in freq:
                freq[s[r]] = 1
            else:
                freq[s[r]] += 1
                
            curr_len = r - l + 1
            
            if curr_len - max(freq.values()) <= k:
                maxlen = max(maxlen, curr_len)
                
            else:
                freq[s[l]] -= 1
                l += 1
                
        return maxlen
        