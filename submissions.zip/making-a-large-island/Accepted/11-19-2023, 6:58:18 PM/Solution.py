// https://leetcode.com/problems/making-a-large-island

# Steps:

# 1. Explore every island using DFS, count its area, give it an island index and save the result to a {index: area} map. Note the grid elements are updated with their corresponding island index. Since the grid has elements 0 or 1. The island index is initialized with -1.

# 2. Loop every cell == 0, check its connected islands and calculate total islands area. The possible connected island index is stored in a set to remove duplicate index.

class Solution:
    def largestIsland(self, grid: List[List[int]]) -> int:
        self.island_id = -1
        self.island_areas = {}

        self.directions = [(1, 0), (-1, 0), (0, 1), (0, -1)]

        for r in range(len(grid)):
            for c in range(len(grid[0])):
                if grid[r][c] == 1:
                    island_area = self.dfs(grid, r, c)

                    self.island_areas[self.island_id] = island_area

                    self.island_id -= 1

        max_area = 0

        for r in range(len(grid)):
            for c in range(len(grid[0])):
                if not grid[r][c]:
                    area = 1
                    surrounding = set()

                    for dr, dc in self.directions:
                        new_r, new_c = r + dr, c + dc

                        if (0 <= new_r < len(grid) and 0 <= new_c < len(grid[0]) and grid[new_r][new_c] != 0):
                            surrounding.add(grid[new_r][new_c])

                    for island_id in surrounding:
                        area += self.island_areas[island_id]

                    max_area = max(max_area, area)

        return max_area if max_area else len(grid) ** 2

    def dfs(self, grid, r, c):
        if (0 <= r < len(grid) and 0 <= c < len(grid[0]) and grid[r][c] == 1):
            grid[r][c] = self.island_id

            area = 1

            for dr, dc in self.directions:
                area += self.dfs(grid, r + dr, c + dc)

            return area

        else:
            return 0

        
# TC : O(N^2), where N is the length and width of the grid. We traverse the grid twice, one with dfs and another when we are looking for empty cells.

# SC : O(N^2), the additional space used in the depth first search by the map island_areas.