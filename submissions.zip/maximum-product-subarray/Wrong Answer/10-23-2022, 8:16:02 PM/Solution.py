// https://leetcode.com/problems/maximum-product-subarray

class Solution:
    def maxProduct(self, nums: List[int]) -> int:
        res = nums[0]
        
        currMax, currMin = 1, 1
        
        for n in nums:
            tmp = currMax * n
            
            currMax = max(n*currMax, n*currMin, n)
            currMin = max(tmp, n*currMin, n)
            res = max(res, currMax)
            
        return res
    

    # TC/SC : O(n)/O(1)
        