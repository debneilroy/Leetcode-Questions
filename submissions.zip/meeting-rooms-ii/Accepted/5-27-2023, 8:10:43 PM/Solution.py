// https://leetcode.com/problems/meeting-rooms-ii

class Solution:
    def minMeetingRooms(self, intervals: List[List[int]]) -> int:

        start = sorted([i[0] for i in intervals])
        end = sorted([i[1] for i in intervals])

        res, count = 0, 0
        s, e = 0, 0

        while s < len(intervals):
            if start[s] < end[e]: # meeting has started
                s += 1
                count += 1
            else: # meeting has ended
                e += 1
                count -= 1
            res = max(res, count)

        return res

# TC : O(nlogn)
# SC : O(logn) if sorting is in place else O(n)