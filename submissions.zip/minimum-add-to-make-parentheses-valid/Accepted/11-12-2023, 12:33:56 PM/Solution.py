// https://leetcode.com/problems/minimum-add-to-make-parentheses-valid

# https://leetcode.com/problems/minimum-add-to-make-parentheses-valid/solutions/181132/c-java-python-straight-forward-one-pass/

# Explanation:
# left records the number of ( we need to add on the left of S.
# right records the number of ) we need to add on the right of S,
# which equals to the number of current opened parentheses.


# Loop char c in the string S:
# if (c == '('), we increment right,
# if (c == ')'), we decrement right.
# When right is already 0, we increment left
# Return left + right in the end

class Solution:
    def minAddToMakeValid(self, s: str) -> int:
        left, right = 0, 0

        for i in s:
            if i == '(':
                right += 1
            elif i == ')':
                if right > 0:
                    right -= 1
                else:
                    left += 1

        return right+left

# TC : O(n)
# SC : O(1)
        