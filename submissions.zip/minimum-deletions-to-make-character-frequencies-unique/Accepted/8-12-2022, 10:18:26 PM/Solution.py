// https://leetcode.com/problems/minimum-deletions-to-make-character-frequencies-unique

class Solution:
    def minDeletions(self, s: str) -> int:
        freq = [0]*26
        
        for char in s:
            freq[ord(char) - ord('a')] += 1
            
        delete_count = 0
        seen_freq = set()
        
        for i in range(26):
            while freq[i] and freq[i] in seen_freq:
                freq[i] -= 1
                delete_count += 1
                
            seen_freq.add(freq[i])
            
        return delete_count
        