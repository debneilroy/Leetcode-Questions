// https://leetcode.com/problems/non-overlapping-intervals

class Solution:
    def eraseOverlapIntervals(self, intervals: List[List[int]]) -> int:
        intervals.sort(key = lambda i : i[0])
        prevEnd = intervals[0][1]
        count = 0

        for start, end in intervals[1:]:

            if start >= prevEnd:
                prevEnd = end
            else:
                count += 1
                prevEnd = min(prevEnd, end)

        return count

# TC : O(nlogn)
# SC : O(logn) if sorting is in place else O(n)
