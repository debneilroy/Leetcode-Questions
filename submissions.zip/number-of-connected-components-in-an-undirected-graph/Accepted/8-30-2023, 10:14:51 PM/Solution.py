// https://leetcode.com/problems/number-of-connected-components-in-an-undirected-graph

# Solution 1 : Union Find by Rank

class Solution:
    def countComponents(self, n: int, edges: List[List[int]]) -> int:

        parent = [i for i in range(n)]
        rank = [1]*n

        def find(n1): # find parent of a node
            res = n1

            while res != parent[res]:
                parent[res] = parent[parent[res]]
                res = parent[res]

            return res

        def union(n1, n2):
            p1, p2 = find(n1), find(n2)

            if p1 == p2:
                return 0

            if rank[p2] > rank[p1]:
                parent[p1] = p2
                rank[p2] += rank[p1]
            else:
                parent[p2] = p1
                rank[p1] += rank[p2]

            return 1

        res = n

        for n1, n2 in edges:
            res -= union(n1, n2)

        return res


    
# Complexity:

# Here E = Number of edges, V = Number of vertices.

# Time complexity: O(V+E⋅α(n)).

# Iterating over every edge requires O(E) operations, and for every operation, we are performing the union method which is O(α(n)), where α(n) is the inverse Ackermann function. We also require O(V) time to initialize the DSU arrays.

# Space complexity: O(V).

# Storing the representative/immediate-parent of each vertex takes O(V) space. Furthermore, storing the size of components also takes O(V) space.


# Solution 2 : DFS

# class Solution:
#     def countComponents(self, n: int, edges: List[List[int]]) -> int:

#         graph = {i:[] for i in range(n)}

#         for x, y in edges:
#             graph[x].append(y)
#             graph[y].append(x)

#         def dfs(node, seen):
#             seen.add(node)

#             for neighbor in graph[node]:
#                 if neighbor not in seen:
#                     dfs(neighbor, seen)


#         seen = set()
#         count = 0

#         for node in range(n):
#             if node not in seen:
#                 dfs(node, seen)
#                 count += 1

#         return count


# TC and SC : O(E + V), where E is the number of edges and V is the number of vertices

