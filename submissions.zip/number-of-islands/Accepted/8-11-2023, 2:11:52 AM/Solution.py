// https://leetcode.com/problems/number-of-islands

# DFS

class Solution:
    def numIslands(self, grid: List[List[str]]) -> int:

        rows, cols = len(grid), len(grid[0])
        visited = set()
        islands = 0

        def dfs(r,c):
            if (r < 0 or c < 0 or r == rows or c == cols or grid[r][c] == "0" or (r,c) in visited):
                return 

            visited.add((r,c))

            dfs(r+1,c)
            dfs(r-1,c)
            dfs(r,c+1)
            dfs(r,c-1)

        for r in range(rows):
            for c in range(cols):
                if grid[r][c] == "1" and (r,c) not in visited:
                    dfs(r,c)
                    islands += 1

        return islands

# TC and SC : O(mn)


# BFS
# class Solution:
#     def numIslands(self, grid: List[List[str]]) -> int:

#         if not grid:
#             return 0

#         rows, cols = len(grid), len(grid[0])
#         visited = set()
#         islands = 0

#         def bfs(r,c):
#             q = deque()
#             q.append((r,c))
#             visited.add((r,c))


#             while q:
#                 r, c = q.popleft()
#                 directions = [[1,0], [-1,0], [0,1], [0,-1]]
#                 for dr, dc in directions:
#                     row, col = r + dr, c + dc
#                     if row in range(rows) and col in range(cols) and grid[row][col] == "1" and (row,col) not in visited:
#                         q.append((row,col))
#                         visited.add((row,col))


#         for r in range(rows):
#             for c in range(cols):
#                 if grid[r][c] == "1" and (r,c) not in visited:
#                     bfs(r,c)
#                     islands += 1

#         return islands



# TC : O(M×N) where M is the number of rows and N is the number of columns.
# SC : O(min(M,N)) because in worst case where the grid is filled with lands, the size of queue can grow up to min(M,N) (for dfs SC is O(M×N))
        