// https://leetcode.com/problems/palindromic-substrings

# Brute Force
# TC : O(n^3), SC : O(1)
# class Solution:
#     def countSubstrings(self, s):
#         count = 0
#         for i in range(len(s)):
#             for j in range(i, len(s)):
#                 if self.isPalindrome(s, i, j):
#                     count += 1
#         return count
    
#     def isPalindrome(self, s, l, r):
#         while l < r:
#             if s[l] != s[r]:
#                 return False
#             l += 1
#             r -= 1
#         return True
        

# Expand around center
# TC : O(n^2), SC : O(1)

class Solution:
    def countSubstrings(self, s):
        count = 0

        for i in range(len(s)):
            count += self.countPalindrome(s, i, i)
            count += self.countPalindrome(s, i, i+1)

        return count

    def countPalindrome(self, s, l, r):
        res = 0
        while l >=0 and r < len(s) and s[l] == s[r]:
            res += 1
            l -= 1
            r += 1

        return res

