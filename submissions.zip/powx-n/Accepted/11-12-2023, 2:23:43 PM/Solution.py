// https://leetcode.com/problems/powx-n

# Binary Exponentiation

# The basic idea here is to use the fact that x^n can be expressed as:

# (x^2)^(n/2), if n is even
# x * (x^2)^{(n-1)/2} if n is odd (we separate out one x, then n − 1 will become even)

class Solution:
    def myPow(self, x: float, n: int) -> float:
        if n == 0:
            return 1

        # Case where n < 0
        if n < 0:
            n = -1 * n
            x = 1 / x

        result = 1
        while n != 0:
            # If 'n' is odd we multiply result with 'x' and reduce 'n' by '1'.
            if n % 2 == 1:
                result *= x
                n -= 1
            # We square 'x' and reduce 'n' by half, x^n => (x^2)^(n/2).
            x *= x
            n //= 2

        return result


# Complexity Analysis

# Time complexity: O(log⁡n)

# At each iteration, we reduce n by half, thus it means we will make only log⁡ n number of iterations using a while loop.

# Space complexity: O(1)

# We don't use any additional space.
        