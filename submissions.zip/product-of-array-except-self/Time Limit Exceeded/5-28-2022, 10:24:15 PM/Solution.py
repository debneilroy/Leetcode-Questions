// https://leetcode.com/problems/product-of-array-except-self

class Solution:
    def productExceptSelf(self, nums):
        n = len(nums)
    
        if n == 0 or n == 1:
            return []
        answer = [1] * n
       
        for i in range(0, n):
            for j in range(0, n):
                if i != j:
                    answer[i] = answer[i] * nums[j]
                    
        return answer
  