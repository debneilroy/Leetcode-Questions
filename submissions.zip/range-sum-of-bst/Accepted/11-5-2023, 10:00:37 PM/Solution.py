// https://leetcode.com/problems/range-sum-of-bst

# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right

# Iterative DFS

# class Solution:
#     def rangeSumBST(self, root: Optional[TreeNode], low: int, high: int) -> int:
#         ans = 0
#         stack = [root]
#         while stack:
#             node = stack.pop()
#             if node:
#                 if low <= node.val <= high:
#                     ans += node.val
#                 if low < node.val:
#                     stack.append(node.left)
#                 if node.val < high:
#                     stack.append(node.right)

#         return ans


# # TC and SC : O(N)        

class Solution:
    def rangeSumBST(self, root: Optional[TreeNode], low: int, high: int) -> int:
        def dfs(node):
            if node:
                if low <= node.val <= high:
                    self.ans += node.val
                if low < node.val:
                    dfs(node.left)
                if node.val < high:
                    dfs(node.right)

        self.ans = 0
        dfs(root)
        return self.ans