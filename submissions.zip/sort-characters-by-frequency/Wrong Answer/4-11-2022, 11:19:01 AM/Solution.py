// https://leetcode.com/problems/sort-characters-by-frequency

class Solution:
    def frequencySort(self, s: str) -> str:
        return ''.join(sorted(s, reverse=True)[::-1])
        