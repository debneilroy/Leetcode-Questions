// https://leetcode.com/problems/subarray-sum-equals-k

# Brute Force (TC : O(n^2)  SC : O(1))

# class Solution:
#     def subarraySum(self, nums: List[int], k: int) -> int:
#         count = 0

#         for start in range(len(nums)):
#             summ = 0
#             for end in range(start, len(nums)):
#                 summ += nums[end]
#                 if (summ == k):
#                     count += 1

#         return count


# Hashmap Approach (whenever sums has increased by a value of k, we've found a subarray of sums=k)
# Hashmap has to be initialised with 0 (e.g, nums = [1,2,1,3], k = 3)
# https://leetcode.com/problems/subarray-sum-equals-k/solutions/341399/python-clear-explanation-with-code-and-example/


class Solution:
    def subarraySum(self, nums: List[int], k: int) -> int:
        count = 0
        sums = 0
        d = {}
        d[0] = 1

        for i in range(len(nums)):
            sums += nums[i]
            count += d.get(sums-k, 0)
            d[sums] = d.get(sums, 0) + 1

        return count


# TC and SC : O(n)  