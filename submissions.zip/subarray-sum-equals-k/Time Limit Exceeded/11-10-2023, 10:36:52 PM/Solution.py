// https://leetcode.com/problems/subarray-sum-equals-k

class Solution:
    def subarraySum(self, nums: List[int], k: int) -> int:
        count = 0

        for start in range(len(nums)):
            summ = 0
            for end in range(start, len(nums)):
                summ += nums[end]
                if (summ == k):
                    count += 1

        return count
        