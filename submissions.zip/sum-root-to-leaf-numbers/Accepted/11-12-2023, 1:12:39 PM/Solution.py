// https://leetcode.com/problems/sum-root-to-leaf-numbers

# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right



# Iterative Preorder Traversal
class Solution:
    def sumNumbers(self, root: Optional[TreeNode]) -> int:
        root_to_leaf = 0
        stack = [(root, 0)]

        while stack:
            root, current_number = stack.pop()
            if root is not None:
                current_number = current_number * 10 + root.val
                # if it is a leaf, update root-to-leaf sum
                if root.left is None and root.right is None:
                    root_to_leaf += current_number
                stack.append((root.left, current_number))
                stack.append((root.right, current_number))

        return root_to_leaf
        