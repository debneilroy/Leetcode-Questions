// https://leetcode.com/problems/sum-root-to-leaf-numbers

# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right



# Iterative Preorder Traversal

class Solution:
    def sumNumbers(self, root: Optional[TreeNode]) -> int:
        root_to_leaf = 0
        stack = [(root, 0)]

        while stack:
            root, current_number = stack.pop()
            if root is not None:
                current_number = current_number * 10 + root.val
                # if it is a leaf, update root-to-leaf sum
                if root.left is None and root.right is None:
                    root_to_leaf += current_number
                stack.append((root.left, current_number))
                stack.append((root.right, current_number))

        return root_to_leaf
        
# Complexity Analysis

# Time complexity: O(N) since one has to visit each node.

# Space complexity: up to O(H) to keep the stack, where H is a tree height.


# Recursive Preorder Traversal

# class Solution:
#     def sumNumbers(self, root: TreeNode):
#         def preorder(r, curr_number):
#             nonlocal root_to_leaf
#             if r:
#                 curr_number = curr_number * 10 + r.val
#                 # if it's a leaf, update root-to-leaf sum
#                 if not (r.left or r.right):
#                     root_to_leaf += curr_number
                    
#                 preorder(r.left, curr_number)
#                 preorder(r.right, curr_number) 
        
#         root_to_leaf = 0
#         preorder(root, 0)
#         return root_to_leaf

# Complexity Analysis

# Time complexity: O(N) since one has to visit each node.

# Space complexity: up to O(H) to keep the recurion stack, where H is a tree height.