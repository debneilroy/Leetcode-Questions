// https://leetcode.com/problems/toeplitz-matrix

#  https://leetcode.com/problems/toeplitz-matrix/solutions/113385/python-easy-and-concise-solution/

class Solution:
    def isToeplitzMatrix(self, matrix: List[List[int]]) -> bool:

        rows, cols = len(matrix), len(matrix[0])

        for i in range(rows-1):
            for j in range(cols-1):
                if matrix[i][j] != matrix[i+1][j+1]:
                    return False

        return True


# TC : O(rows*cols) SC : O(1)     