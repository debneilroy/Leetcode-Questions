// https://leetcode.com/problems/valid-anagram

class Solution:
    def isAnagram(self, s: str, t: str) -> bool:
        dict1, dict2 = [0]*26, [0]*26
        
        for item in s:
            dict1[ord(item)-ord('a')] += 1
            
        for item in t:
            dict2[ord(item)-ord('a')] += 1
            
        return dict1 == dict2
            
        