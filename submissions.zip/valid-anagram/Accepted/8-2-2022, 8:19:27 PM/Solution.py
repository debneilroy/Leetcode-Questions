// https://leetcode.com/problems/valid-anagram

class Solution:
    def isAnagram(self, s: str, t: str) -> bool:
        
        dict_s = {}
        dict_t = {}
        
        def create(s):
            dic = {}
            
            for x in s:
                if x in dic:
                    dic[x] += 1
                else:
                    dic[x] = 1
                    
            return dic
                
        dict_s = create(s)
        dict_t = create(t)
        
        print(dict_s)
        print(dict_t)
        
        for key, value in dict_s.items():
            if key in dict_t:
                if dict_t[key] != value:
                    return False
            else:
                return False
            
            
        for key, value in dict_t.items():
            if key in dict_s:
                if dict_s[key] != value:
                    return False
            else:
                return False
            
        return True
            
        
        
        
        