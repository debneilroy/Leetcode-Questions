// https://leetcode.com/problems/valid-anagram

class Solution:
    def isAnagram(self, s: str, t: str) -> bool:
        
        dict_s = {}
        dict_t = {}
        
        for x in s:
            dict_s[x] = dict_s.get(x, 0) + 1
            
        for x in t:
            dict_t[x] = dict_t.get(x, 0) + 1
            
        
        for key, value in dict_s.items():
            if key in dict_t:
                if value != dict_t[key]:
                    return False
            else:
                return False
            
        # for key, value in dict_t.items():
        #     if key in dict_s:
        #         if value != dict_s[key]:
        #             return False
        #     else:
        #         return False
                
        return True
        
            
        
        
        
        