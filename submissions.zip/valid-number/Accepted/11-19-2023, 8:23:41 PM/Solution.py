// https://leetcode.com/problems/valid-number

# Solution : https://www.youtube.com/watch?v=5c6MdetEfoA

class Solution:
    def isNumber(self, s: str) -> bool:
        decimal_used = False
        number_seen = False

        i = 0

        if s[i] in ['+', '-']:
            i += 1

        while i < len(s):
            char = s[i]

            if char.isalpha():
                if char not in ['e', 'E']:
                    return False
                else:
                    return number_seen and self.is_valid_integer(s[i+1:])
            elif char == '.':
                if decimal_used:
                    return False
                else:
                    decimal_used = True
            elif char in ['+', '-']:
                return False
            else:
                number_seen = True

            i += 1

        return number_seen


    def is_valid_integer(self, s):
        if s == '':
            return False

        number_seen = False

        i = 0

        if s[i] in ['+', '-']:
            i += 1

        while i < len(s):
            char = s[i]

            if not char.isdigit():
                return False
            else:
                number_seen = True

            i += 1

        return number_seen
        
# TC : O(N), where N is the length of s.
# SC : O(1)