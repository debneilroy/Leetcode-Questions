// https://leetcode.com/problems/valid-word-abbreviation

# https://leetcode.com/problems/valid-word-abbreviation/solutions/271799/python-solution-with-explanation/

class Solution:
    def validWordAbbreviation(self, word: str, abbr: str) -> bool:
        i, j = 0, 0

        while i < len(word) and j < len(abbr):
            if abbr[j].isalpha():
                if word[i] != abbr[j]:
                    return False
                i += 1
                j += 1
            else:
                if abbr[j] == "0":
                    return False
                tmp = ""
                while j < len(abbr) and abbr[j].isdigit():
                    tmp = tmp + abbr[j]
                    j += 1
                i += int(tmp)

        return i == len(word) and j == len(abbr)

# TC : O(N) SC : O(1)

        